package GL.IA.appformation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
